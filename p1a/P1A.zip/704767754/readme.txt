Included Files:

calulator.php
     The main file of the project. Contains HTML of the calculator page, as well as the PHP code to process form submissions and GET requests.

team.txt
     Includes comma separated UIDs of Lawrence Chen and Kubilay Agi

We did pair programming, because we believed it was an easy project so working together would be the most efficient. We also took the opportunity to get more familiar with PHP and understand how to set up the virtual environment.
