We met all project criteria and implemented all features.
We have a search page with search functionality with keywords of actors and movies.
We can add new people into our database, including actors and directors.
We can also add new movies, and also add actor to movie relations and director to movie relations.
We can also display information about specific actors or movies.
In the movie info page, there is also an option to add reviews for the movie.

We worked together in peer programming when we were learning new concepts, like how to make a specific type of query or laying out the basic form. However, once we got a hang of it, we split up similar functionalities to each person if they happen to be distinct pages. For example, Lawrence worked on Actor Info while Kubilay worked on Movie Info, so that way both of us got experience working with different types of queries and data representations. 

We realized that we may not always be available at the same time, so an improvement we need to make (which we began to do so in this project) is to utilize Github to our advantage and learn to work with different files and handle merge conflicts if necessary. This makes the coding process more efficient.